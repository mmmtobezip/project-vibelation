압축을 풀고 vibelation-white.html 파일을 Chrome으로 여세요. 별도 설치는 필요하지 않습니다.
